"""Stub used by Terraform when first creating Lambda functions. Replaced
by the real code on the next deploy-backend.yml workflow run."""


def handler(event, context):
    return {
        "statusCode": 503,
        "headers": {"Content-Type": "application/json"},
        "body": '{"error":"Lambda not yet deployed — re-run deploy-backend"}',
    }
